@extends('backend.app')

@section('content')

@if (session('success'))
<div class="alert alert-success alert-dismissible fade show m-3" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="container-fluid" style="height: calc(100vh - 80px); overflow-y: auto; padding-bottom: 20px;">

    <div class="row m-3 align-items-center mb-3">
        <div class="col-md-6">
            <h2 class="fw-bold mb-1">
                Worker List
                <span style="font-size:15px;" class="badge rounded-pill bg-primary-subtle text-primary px-3 py-2">
                    <i class="bi bi-person"></i>
                    {{ $posts->count() }} Workers
                </span>
            </h2>
            <small class="text-muted">সকল workers (user-linked এবং manually added)</small>
        </div>
        <div class="col-md-6 text-end">
            <a href="{{ url('admin/workers/create') }}" class="btn btn-primary">
                <i class="bi bi-plus-circle me-1"></i> Add New Worker
            </a>
        </div>
    </div>

    <div class="card mx-3 shadow-sm border-0 rounded-3">
        <div class="card-body p-2">

            <div class="mb-3">
                <input type="text" id="postSearch" class="form-control" placeholder="Search workers by name, email or category...">
            </div>

            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered align-middle text-center mb-0">

                    <thead class="table-light">
                        <tr>
                            <th style="width:50px;">#</th>
                            <th style="width:150px;">Name</th>
                            <th style="width:170px;">Account (Email)</th>
                            <th style="width:120px;">Category</th>
                            <th style="width:150px;">Contact Number</th>
                            <th style="width:120px;">Division</th>
                            <th style="width:100px;">File</th>
                            <th style="width:120px;">Status</th>
                            <th style="width:200px;">Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        @forelse ($posts as $post)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td class="fw-medium text-center">{{ $post->title }}</td>
                            <td class="text-muted small">
                                @if($post->user)
                                    <i class="bi bi-person-fill text-primary me-1"></i>
                                    {{ $post->user->email }}
                                @else
                                    <span class="text-muted">—</span>
                                @endif
                            </td>
                            <td>{{ $post->PostCategory->name ?? 'No Category' }}</td>
                            <td>{{ $post->contact_number }}</td>
                            <td>{{ $post->division }}</td>

                            <td>
                                @if($post->file)
                                    @php
                                        $ext = strtolower(pathinfo($post->file, PATHINFO_EXTENSION));
                                        $videoExtensions = ['mp4','webm','ogg','asf','avi','flv','mkv'];
                                        $imageExtensions = ['jpg','jpeg','png','gif','webp'];
                                        $isImage = in_array($ext, $imageExtensions);
                                        $isVideo = in_array($ext, $videoExtensions);
                                    @endphp

                                    @if($isImage)
                                        <a href="#"
                                           class="media-preview"
                                           data-bs-toggle="modal"
                                           data-bs-target="#mediaModal"
                                           data-type="image"
                                           data-src="{{ config('app.storage_url') }}{{ $post->file }}">
                                            <img src="{{ config('app.storage_url') }}{{ $post->file }}"
                                                 class="img-thumbnail"
                                                 style="width:50px;height:50px;object-fit:cover;">
                                        </a>
                                    @elseif($isVideo)
                                        <a href="#"
                                           class="media-preview"
                                           data-bs-toggle="modal"
                                           data-bs-target="#mediaModal"
                                           data-type="video"
                                           data-src="{{ config('app.storage_url') }}{{ $post->file }}">
                                            <video class="img-thumbnail"
                                                   style="width:50px;height:50px;object-fit:cover;"
                                                   src="{{ config('app.storage_url') }}{{ $post->file }}"
                                                   muted>
                                            </video>
                                        </a>
                                    @else
                                        <span class="text-muted">Unsupported File</span>
                                    @endif
                                @else
                                    <span class="text-muted">No File</span>
                                @endif
                            </td>

                            <td>
                                @if($post->status == 1)
                                    <span class="badge bg-success">Active</span>
                                @else
                                    <span class="badge bg-warning text-dark">Pending</span>
                                @endif
                            </td>

                            <td>
                                <button class="btn btn-sm btn-warning"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editModal{{ $post->id }}">
                                    <i class="bi bi-pencil"></i> Edit
                                </button>

                                <button class="btn btn-sm btn-danger"
                                        onclick="confirmation({{ $post->id }})">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            </td>
                        </tr>

                        @include('backend.posts.editmodal')

                        @empty
                        <tr>
                            <td colspan="9" class="text-muted py-4">
                                <i class="bi bi-inbox fs-4 d-block mb-1"></i>
                                কোনো worker প্রোফাইল তৈরি করেননি এখনো।
                            </td>
                        </tr>
                        @endforelse
                    </tbody>

                </table>
            </div>

        </div>
    </div>
</div>


<!-- MEDIA MODAL -->
<div class="modal fade" id="mediaModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header">
                <h5 class="modal-title">Media Preview</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="mediaImage" class="img-fluid d-none" style="max-height:500px;">
                <video id="mediaVideo" class="img-fluid d-none" controls style="max-height:500px;">
                    <source id="mediaVideoSource">
                </video>
                <iframe id="mediaIframe" class="d-none" style="width:100%;height:500px;border:0;"></iframe>
            </div>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {

    // ================= MEDIA MODAL =================
    const mediaModal = document.getElementById('mediaModal');
    const mediaImage = document.getElementById('mediaImage');
    const mediaVideo = document.getElementById('mediaVideo');
    const mediaVideoSource = document.getElementById('mediaVideoSource');
    const mediaIframe = document.getElementById('mediaIframe');

    document.querySelectorAll('.media-preview').forEach(el => {
        el.addEventListener('click', function () {
            const type = el.dataset.type;
            const src  = el.dataset.src;
            const ext  = src.split('.').pop().toLowerCase();

            mediaImage.classList.add('d-none');
            mediaVideo.classList.add('d-none');
            mediaIframe.classList.add('d-none');
            mediaVideo.pause();

            if (type === 'image') {
                mediaImage.src = src;
                mediaImage.classList.remove('d-none');
            } else if (type === 'video') {
                if (ext === 'asf') {
                    mediaIframe.src = src;
                    mediaIframe.classList.remove('d-none');
                } else {
                    mediaVideoSource.src = src;
                    mediaVideo.load();
                    mediaVideo.classList.remove('d-none');
                }
            }
        });
    });

    mediaModal.addEventListener('hidden.bs.modal', function () {
        mediaVideo.pause();
        mediaImage.src = '';
        mediaVideoSource.src = '';
        mediaIframe.src = '';
    });

    // ================= DELETE CONFIRMATION =================
    window.confirmation = function (id) {
        Swal.fire({
            title: 'Delete Worker',
            text: 'এই worker কে delete করতে চান?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'হ্যাঁ, Delete করো',
            cancelButtonText: 'বাতিল'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '/admin/workers/delete/' + id;
            }
        });
    }

    // ================= LIVE SEARCH =================
    const postSearch = document.getElementById('postSearch');
    const tableRows  = document.querySelectorAll('table tbody tr:not([id])');

    postSearch.addEventListener('keyup', function () {
        const query = this.value.toLowerCase().trim();

        tableRows.forEach(row => {
            const name     = row.querySelector('td:nth-child(2)')?.textContent.toLowerCase() || '';
            const email    = row.querySelector('td:nth-child(3)')?.textContent.toLowerCase() || '';
            const category = row.querySelector('td:nth-child(4)')?.textContent.toLowerCase() || '';

            row.style.display = (name.includes(query) || email.includes(query) || category.includes(query)) ? '' : 'none';
        });

        const visibleRows = Array.from(tableRows).filter(r => r.style.display !== 'none');
        const noRow = document.getElementById('noPostsRow');
        if (visibleRows.length === 0) {
            if (!noRow) {
                const tbody = document.querySelector('table tbody');
                const emptyRow = document.createElement('tr');
                emptyRow.id = 'noPostsRow';
                emptyRow.innerHTML = '<td colspan="9" class="text-muted text-center py-3">কোনো worker পাওয়া যায়নি।</td>';
                tbody.appendChild(emptyRow);
            }
        } else {
            if (noRow) noRow.remove();
        }
    });

});
</script>


<style>
.table-hover tbody tr:hover {
    background-color: rgba(13,110,253,0.05);
    transition: .2s;
}
.card-body { border-radius: 12px; }
.btn-sm i  { margin-right: 4px; }
.alert     { border-radius: 12px; font-size: 14px; }
.fw-medium { font-weight: 500; }

@media (max-width: 992px) {
    .table-responsive { overflow-x: auto; }
    table th, table td { white-space: nowrap; font-size: 13px; }
}
@media (max-width: 576px) {
    table th, table td { font-size: 12px; padding: 0.35rem; }
    .btn-sm { font-size: 12px; padding: 4px 6px; }
}
</style>

@endsection
